package org.jetbrains.idea.tomcat.descriptor;

import com.intellij.javaee.oss.descriptor.JavaeeDescriptorsProviderBase;
import org.jetbrains.idea.tomcat.server.TomcatIntegration;

public class TomcatDescriptorsProvider extends JavaeeDescriptorsProviderBase {
  public TomcatDescriptorsProvider(TomcatIntegration tomcatIntegration) {
    super(tomcatIntegration);
  }
}
