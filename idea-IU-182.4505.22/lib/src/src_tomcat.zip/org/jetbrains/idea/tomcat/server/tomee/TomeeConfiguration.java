package org.jetbrains.idea.tomcat.server.tomee;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.idea.tomcat.server.TomcatConfigurationBase;

public class TomeeConfiguration extends TomcatConfigurationBase {

  public TomeeConfiguration() {
    super(TomeeIntegration.getTomeeInstance());
  }

  @NotNull
  @Override
  public String getId() {
    return "TomeeConfiguration";
  }
}
