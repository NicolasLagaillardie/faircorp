// Copyright 2000-2017 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package icons;

import com.intellij.openapi.util.IconLoader;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run "Generate icon classes" configuration instead
 */
public class SpringBootApiIcons {
  private static Icon load(String path) {
    return IconLoader.getIcon(path, SpringBootApiIcons.class);
  }


  public static class Gutter {
    public static final Icon SpringBoot = load("/icons/gutter/springBoot.png"); // 12x12

  }
  public static final Icon SpringBoot = load("/icons/SpringBoot.png"); // 16x16
  public static final Icon SpringBoot_Overlay = load("/icons/SpringBoot_Overlay.png"); // 16x16
}
