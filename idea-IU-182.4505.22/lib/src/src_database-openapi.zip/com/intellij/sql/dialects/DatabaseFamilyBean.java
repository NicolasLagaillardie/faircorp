package com.intellij.sql.dialects;

import com.intellij.database.DatabaseFamilyId;
import com.intellij.database.dialects.DatabaseDialect;
import com.intellij.openapi.application.Application;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.extensions.*;
import com.intellij.openapi.extensions.impl.ExtensionsAreaImpl;
import com.intellij.openapi.util.Condition;
import com.intellij.openapi.util.JDOMUtil;
import com.intellij.openapi.util.NotNullLazyValue;
import com.intellij.util.ObjectUtils;
import com.intellij.util.ReflectionUtil;
import com.intellij.util.containers.JBIterable;
import com.intellij.util.xmlb.JDOMXIncluder;
import com.intellij.util.xmlb.annotations.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.TestOnly;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.URL;

public class DatabaseFamilyBean extends AbstractExtensionPointBean {
  public static final ExtensionPointName<DatabaseFamilyBean> EP_NAME =
    ExtensionPointName.create("com.intellij.database.databaseFamily");

  @Attribute("familyId")
  public String familyId;

  @Attribute("rdbms")
  public String rdbms;

  @Attribute("languageClass")
  public String languageClass;

  @Attribute("dialectClass")
  public String dialectClass;

  public final NotNullLazyValue<SqlLanguageDialect> language = NotNullLazyValue.createValue(() -> getInstanceField(languageClass));

  public final NotNullLazyValue<DatabaseDialect> dialect = NotNullLazyValue.createValue(() -> getInstanceField(dialectClass));

  public final NotNullLazyValue<DatabaseFamilyId> family = NotNullLazyValue.createValue(
    () -> ObjectUtils.assertNotNull(DatabaseFamilyId.byName(familyId)));

  @Nullable
  public static DatabaseFamilyBean findFamily(@NotNull Condition<? super DatabaseFamilyBean> condition) {
    DatabaseFamilyBean[] extensions = getExtensions();
    if (extensions == null) return null;
    for (DatabaseFamilyBean extension: extensions) {
      if (condition.value(extension)) return extension;
    }
    return null;
  }

  @Nullable
  public static DatabaseFamilyBean findByRdbms(@Nullable String rdbms) {
    return rdbms == null ? null : findFamily(f -> rdbms.equals(f.rdbms));
  }

  @Nullable
  public static DatabaseFamilyBean findByFamilyId(@Nullable DatabaseFamilyId familyId) {
    return familyId == null ? null : findFamily(f -> familyId.equals(f.family.getValue()));
  }

  @SuppressWarnings("unchecked")
  private <T> T getInstanceField(String className) {
    try {
      Class<T> clazz = findClass(className);
      Field field = clazz.getField("INSTANCE");
      if (!Modifier.isStatic(field.getModifiers())) throw new AssertionError("INSTANCE field is not static");
      return (T)field.get(null);
    }
    catch (ReflectiveOperationException e) {
      throw new AssertionError(e);
    }
  }

  @TestOnly
  @NotNull
  @SuppressWarnings("unchecked")
  public <T> T getDialectClass(String suffix) {
    String base = languageClass.replace("Hsqldb", "Hsql");
    return (T)ReflectionUtil.newInstance(ReflectionUtil.forName(base.replace("Dialect", suffix)));
  }


  @Nullable
  public static DatabaseFamilyBean[] getExtensions() {
    if (Extensions.getRootArea().hasExtensionPoint(EP_NAME)) return EP_NAME.getExtensions();
    Application app = ApplicationManager.getApplication();
    if (app == null || app.isUnitTestMode()) return TestHelper.getExtensions();
    return null;
  }

  private static class TestHelper {
    private static final ExtensionsArea ourArea = new ExtensionsAreaImpl(null, null, null);
    static {
      ourArea.registerExtensionPoint(EP_NAME.getName(), DatabaseFamilyBean.class.getCanonicalName(), ExtensionPoint.Kind.BEAN_CLASS);
      ExtensionPoint<DatabaseFamilyBean> point = ourArea.getExtensionPoint(EP_NAME);
      DefaultPluginDescriptor descriptor = new DefaultPluginDescriptor(PluginId.getId("com.intellij.database"), DatabaseFamilyBean.class.getClassLoader());
      URL xml = descriptor.getPluginClassLoader().getResource("/META-INF/dialects/all-dialects.xml");
      if (xml != null) {
        try (InputStream stream = xml.openStream()) {
          Document doc = JDOMUtil.loadDocument(stream);
          doc = JDOMXIncluder.resolve(doc, xml.toExternalForm());
          JBIterable<Element> beans = JBIterable.from(doc.getRootElement().getChildren("extensions")).flatten(e -> e.getChildren())
                                                .filter(e -> e.getName().endsWith("databaseFamily"));
          for (Element bean: beans) {
            ourArea.registerExtension(point, descriptor, bean);
          }
        }
        catch (Exception e) {
          throw new AssertionError("Failed to load dialect list", e);
        }
      }
    }
    @NotNull
    public static DatabaseFamilyBean[] getExtensions() {
      return ourArea.getExtensionPoint(EP_NAME).getExtensions();
    }
  }
}
