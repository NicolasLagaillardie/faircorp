package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlCaseExpression extends SqlExpression {
}