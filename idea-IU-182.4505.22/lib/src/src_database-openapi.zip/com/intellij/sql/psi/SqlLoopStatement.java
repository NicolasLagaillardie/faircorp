package com.intellij.sql.psi;

/**
 * @author gregsh
 */
public interface SqlLoopStatement extends SqlStatement {
}
