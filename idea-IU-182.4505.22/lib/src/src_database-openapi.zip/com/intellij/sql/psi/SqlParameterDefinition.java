package com.intellij.sql.psi;

import com.intellij.database.model.DasArgument;

/**
 * @author gregsh
 */
public interface SqlParameterDefinition extends SqlVariableDefinition, DasArgument {
}
