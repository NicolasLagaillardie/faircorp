package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlUnionExpression extends SqlSetOperatorExpression {
}
