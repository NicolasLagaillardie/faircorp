package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlSetStatement extends SqlStatement{
}