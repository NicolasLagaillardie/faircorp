package icons;

import com.intellij.openapi.util.IconLoader;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run "Generate icon classes" configuration instead
 */
public class J2eeOpenapiIcons {
  private static Icon load(String path) {
    return IconLoader.getIcon(path, J2eeOpenapiIcons.class);
  }

  public static final Icon Ejb_artifact = load("/icons/javaee/ejb_artifact.png"); // 16x16
  public static final Icon Javaee_artifact = load("/icons/javaee/javaee_artifact.png"); // 16x16
  public static final Icon Web_artifact = load("/icons/javaee/web_artifact.png"); // 16x16
}
