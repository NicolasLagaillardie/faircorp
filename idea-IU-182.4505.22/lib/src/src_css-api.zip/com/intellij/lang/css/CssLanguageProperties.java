package com.intellij.lang.css;

import org.jetbrains.annotations.NotNull;

public interface CssLanguageProperties {
  @NotNull
  String getDeclarationsTerminator();

  boolean isIndentBased();
}
