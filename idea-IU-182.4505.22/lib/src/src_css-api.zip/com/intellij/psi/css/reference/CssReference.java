package com.intellij.psi.css.reference;

import com.intellij.codeInsight.daemon.EmptyResolveMessageProvider;
import com.intellij.psi.PsiReference;

public interface CssReference extends PsiReference, EmptyResolveMessageProvider {
}
