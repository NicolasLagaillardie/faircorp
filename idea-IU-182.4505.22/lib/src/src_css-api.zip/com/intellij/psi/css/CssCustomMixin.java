package com.intellij.psi.css;

import com.intellij.psi.NavigatablePsiElement;
import com.intellij.psi.PsiNameIdentifierOwner;

public interface CssCustomMixin extends CssNamedElement, CssOneLineStatement, NavigatablePsiElement, PsiNameIdentifierOwner {
}
