package com.intellij.psi.css;

import com.intellij.psi.PsiElement;
import com.intellij.psi.css.descriptor.CssElementDescriptor;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;

public interface CssDescriptorOwner extends CssElement {

  @NotNull
  Collection<? extends CssElementDescriptor> getDescriptors();
  
  @NotNull
  Collection<? extends CssElementDescriptor> getDescriptors(@NotNull PsiElement context);
}
