package com.intellij.psi.css.descriptor;

import com.intellij.psi.css.descriptor.value.CssValueDescriptor;
import org.jetbrains.annotations.NotNull;

/**
 * User: zolotov
 * <p/>
 * Represent descriptor of css element that could have value descriptor.
 */
public interface CssValueOwnerDescriptor extends CssElementDescriptor {
  @NotNull
  CssValueDescriptor getValueDescriptor();
}
